Copyright (c) 2022 Digital Moons
https://digitalmoons.itch.io/

Customer support email: digitalmoonsstudio@gmail.com
Discord: @DigitalMoons#3448

--------------------------------
By buying this background pack you have a permission to use the content of it as a part of your personal or commercial project, for example as a background for your game, website or app. You're not allowed to share, re-sell or redistribute this background pack or any assets/backgrounds/images from it outside from your project in any way or on any platform. You arent allowed to re-sell or alter and re-sell the images, or otherwise attempt to claim the work as your own.


Link to the asset pack:
https://digitalmoons.itch.io/pixel-city
--------------------------------


Pixel City - Pixel art Background pack by Digital Moons
versio 1.0 

Content:

- Format: .png

- Size: 240x135px

 
--------------------------------
 
If you have any suggestions about how to improve this pack, please leave a comment below the asset on itch.io

Thank you for buying this background pack! 
- Digital Moons